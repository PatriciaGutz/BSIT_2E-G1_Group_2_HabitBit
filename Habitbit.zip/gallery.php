<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HabitBit - Gallery</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light custom-navbar">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
                <img src="images/logo.png" alt="HabitBit Logo" height="40" class="me-2">
                <span class="fw-bold text-white fs-3">HabitBit</span>
            </a>
            <div class="d-flex text-white small">
                <a href="dashboard.php" class="text-white text-decoration-none me-3">Home</a>
                <a href="contact.php" class="text-white text-decoration-none me-3">Contact</a>
                <a href="about.php" class="text-white text-decoration-none me-3">About</a>
                 <a href="gallery.php" class="text-white text-decoration-none me-3 nav-active">Gallery</a>
                <a href="#" class="text-white text-decoration-none">🔔</a>
            </div>
        </div>
    </nav>


    <div class="container my-5">
        <h2 class="text-center mb-5 section-title">User Progress Gallery</h2>

        <h4 class="section-title">Daily Progress and Charts</h4>
        <div class="scroll-container">
            <div class="gallery-card card">
                <img src="images/Goal.png" alt="Progress Stats">
                <div class="card-body">
                    <p class="text-center gallery-text">Visual Progress Monitoring Chart</p>
                </div>
            </div>
            <div class="gallery-card card">
                <img src="images/Monthly.png" alt="Calendar Tracker">
                <div class="card-body">
                    <p class="text-center gallery-text">Monthly Calendar Habit Tracker</p>
                </div>
            </div>
            <div class="gallery-card card">
                <img src="images/Daily.png" alt="Habit List">
                <div class="card-body">
                    <p class="text-center gallery-text">Daily Habit Update Interface</p>
                </div>
            </div>
        </div>

        <h4 class="section-title">Achievements and Motivation</h4>
        <div class="scroll-container">
            <div class="gallery-card card">
                <img src="images/Streak.png" alt="Streak Badge">
                <div class="card-body">
                    <p class="text-center gallery-text">User Streak and Milestone Badges</p>
                </div>
            </div>
            <div class="gallery-card card">
                <img src="images/Quote.png" alt="Quote Wall">
                <div class="card-body">
                    <p class="text-center gallery-text">Motivational Time Bound Messages</p>
                </div>
            </div>
            <div class="gallery-card card">
                <img src="images/Progress.png" alt="Goal Completion">
                <div class="card-body">
                    <p class="text-center gallery-text">Personalized Goal Completion Showcase</p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script.js"></script>
</body>
</html>