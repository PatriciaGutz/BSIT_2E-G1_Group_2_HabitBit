<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>HabitBit - About Us</title>

    <link
      href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css"
    />

    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light custom-navbar">
      <div class="container-fluid">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
          <img
            src="images/logo.png"
            alt="HabitBit Logo"
            height="40"
            class="me-2"
          >
          <span class="fw-bold text-white fs-3">HabitBit</span>
          </a>
            <div class="ms-auto">
                <a href="landingabout.php" class="text-white text-decoration-none me-3 fw-bold">About</a>
                <a href="landingservices.php" class="text-white text-decoration-none me-3">Services</a>
                <a href="landingcontact.php" class="text-white text-decoration-none me-3">Contact</a>
            </div>
        </div>
      </div>
    </nav>

    <main class="container py-5">
      <div class="text-center mb-5">
        <h1 class="display-4 fw-bold">
          About <span class="text-orange">HabitBit</span>
        </h1>
        <p class="lead text-muted">Empowering your journey to better habits.</p>
      </div>

      <section class="row align-items-center g-5 mb-5">
        <div class="col-md-6">
          <h2 class="fw-bold mb-4">Our Mission</h2>
          <p class="text-muted">
            At HabitBit, we believe that small, consistent actions lead to
            life-changing results. Our platform is designed to transform daily
            tasks into sustainable habits.
          </p>
        </div>
        <div class="col-md-6 text-center">
          <div
            class="hero-card p-5 shadow-sm rounded-5 bg-peach-custom border-0"
          >
            <i class="bi bi-rocket-takeoff text-orange fs-1"></i>
            <h1 class="text-orange fw-bold display-3 mt-2">1% Better</h1>
            <p class="text-dark fw-medium">Every single day, bit by bit.</p>
          </div>
        </div>
      </section>

      <section class="text-center my-5 py-4">
        <h2 class="fw-bold mb-5">Our Values</h2>
        <div class="row g-4">
          <div class="col-md-4">
            <div
              class="value-card p-4 rounded-4 bg-white shadow-sm border h-100"
            >
              <i class="bi bi-heart-fill text-danger fs-2"></i>
              <h5 class="fw-bold mt-3">Simplicity</h5>
              <p class="small text-muted">Clean and easy-to-use interface.</p>
            </div>
          </div>
          <div class="col-md-4">
            <div
              class="value-card p-4 rounded-4 bg-white shadow-sm border h-100"
            >
              <i class="bi bi-shield-check text-success fs-2"></i>
              <h5 class="fw-bold mt-3">Consistency</h5>
              <p class="small text-muted">Success through small steps.</p>
            </div>
          </div>
          <div class="col-md-4">
            <div
              class="value-card p-4 rounded-4 bg-white shadow-sm border h-100"
            >
              <i class="bi bi-people-fill text-primary fs-2"></i>
              <h5 class="fw-bold mt-3">Community</h5>
              <p class="small text-muted">Growing together with our users.</p>
            </div>
            </div>
      </section>
    </main>

    <footer class="py-4 text-center">
        <p class="text-muted small">&copy; 2026 HabitBit. All rights reserved.</p>
    </footer>

    <script src="js/main.js"></script>
  </body>
</html>
