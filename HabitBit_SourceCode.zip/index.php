<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HabitBit - Welcome</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/landingstyle.css">
</head>
<body class="bg-white">

    <nav class="navbar navbar-expand-lg navbar-light custom-navbar">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <img src="images/logo.png" alt="HabitBit Logo" height="40" class="me-2">
                <span class="fw-bold text-white fs-3">HabitBit</span>
            </a>
            <div class="ms-auto">
                <a href="landingabout.php" class="text-white text-decoration-none me-3">About</a>
                <a href="landingservices.php" class="text-white text-decoration-none me-3">Services</a>
                <a href="landingcontact.php" class="text-white text-decoration-none me-3">Contact</a>
            </div>
        </div>
    </nav>

    <div class="container hero-section">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-3 fw-bold mb-4">
                    Track today, <br>
                    <span style="color: var(--hb-teal)">Improve tomorrow.</span>
                </h1>
                <p class="lead text-muted mb-5">
                   HabitBit is a web-based habit planning and tracking application that helps users monitor daily habits, build consistency, and improve their routines through simple and organized tracking.
                </p>
                <div class="d-flex gap-3">
                    <a href="login.php" class="btn btn-orange-landing px-5 py-3 rounded-pill shadow">Login</a>
                    <a href="register.php" class="btn btn-outline-teal px-5 py-3 rounded-pill">Register</a>
                </div>
            </div>
            
            <div class="col-lg-6 text-center mt-5 mt-lg-0">
                <img src="images/Monthly.png" alt="HabitBit App Preview" class="landing-img shadow-lg">
            </div>
        </div>
    </div>

</body>
</html>