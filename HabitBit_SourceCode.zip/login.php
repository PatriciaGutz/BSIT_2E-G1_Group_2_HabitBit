<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - HabitBit</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/landingstyle.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light custom-navbar">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <img src="images/logo.png" alt="HabitBit Logo" height="45" class="me-2">
                <span class="fw-bold text-white fs-2">HabitBit</span>
            </a>
        </div>
    </nav>

    <div class="container auth-container">
        <div class="card">
            <h2 class="fw-bold text-center mb-2">Welcome Back</h2>
            <p class="text-center text-muted mb-4">Login to your account.</p>
            
            <form id="loginForm" novalidate>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Email Address *</label>
                    <input type="email" id="loginEmail" class="form-control" placeholder="Enter your email">
                    <span id="loginEmailError" class="error-msg"></span>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Password *</label>
                    <div class="password-wrapper">
                        <input type="password" id="loginPassword" class="form-control" placeholder="Enter password">
                        <i class="bi bi-eye-slash toggle-password" id="toggleLoginPass"></i>
                    </div>
                    <span id="loginPassError" class="error-msg"></span>
                </div>
                <button type="submit" id="loginBtn" class="btn btn-habitbit w-100 mt-2" disabled>Login</button>
            </form>
            <div class="text-center mt-4">
                <p class="small mb-1">Don't have an account? <a href="register.php" class="text-orange fw-bold text-decoration-none">Register here</a></p>
            </div>
        </div>
    </div>
    <script src="js/landingscript.js"></script>
</body>
</html>

<!-- Sanaakonalang12 -->
<!-- Inihawnadinosaur12 -->